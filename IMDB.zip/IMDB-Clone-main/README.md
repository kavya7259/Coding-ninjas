# IMDB Clone
 This is an IMDB clone using HTML, CSS, JS and OMDB API

Live Link :- https://rajeevkrs.github.io/IMDB-Clone/


If you like my project, make sure to give a star to my repository !!
